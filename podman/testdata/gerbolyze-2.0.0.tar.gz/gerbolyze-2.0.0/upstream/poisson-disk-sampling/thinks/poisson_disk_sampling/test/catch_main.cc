// Copyright(C) Tommy Hinks <tommy.hinks@gmail.com>
// This file is subject to the license terms in the LICENSE file
// found in the top-level directory of this distribution.

#define CATCH_CONFIG_MAIN
#include "catch2/catch.hpp"
