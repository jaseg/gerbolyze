# base64 (C++)

Base64 encoding and decoding with c++

## See also

https://renenyffenegger.ch/notes/development/Base64/Encoding-and-decoding-base-64-with-cpp
